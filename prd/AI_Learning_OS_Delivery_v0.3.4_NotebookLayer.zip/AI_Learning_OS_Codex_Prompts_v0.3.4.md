# Codex 提示词（新增 Export Center）v0.3.4
日期：2025-12-30

## P0：Export Markdown ZIP
实现 /exports（create/list/download），生成 Markdown ZIP：00_Index + TechCards/Playbooks/Practices/Sessions。
必须写入 frontmatter（learn_status/verification/interaction_mode/evidence_links）与 backlinks（Open in Replay）。

## P1：Publish Connector（占位）
前端加入 Publish modal；后端 endpoint 先返回 501（提示 P1 才开启）。
