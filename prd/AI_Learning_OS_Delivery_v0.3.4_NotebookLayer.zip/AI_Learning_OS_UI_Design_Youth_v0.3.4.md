# 未成年人版 UI 设计（新增 Portfolio Export/Publish）v0.3.4
日期：2025-12-30

- Portfolio 安全导出（P0）：`youth_15_portfolio_publish.png`
- Publish（P1）需教师审批；发布内容仍为安全版（不含全量对话）
