# OpenNotebook 集成方案（双层架构）v0.3.4
日期：2025-12-30

## 1. 推荐结论
- OpenNotebook **不是 MVP 必须**，但能大幅提升“长期沉淀/阅读/编辑/检索”体验。
- 推荐：AI Learning OS（System of Record） + Notebook（Knowledge Surface）
- 推荐：**单向发布（One-way publish）**，避免双向同步冲突。

## 2. P0：Export Markdown ZIP（零集成）
- 一键导出 ZIP → 导入 OpenNotebook 或放到 Obsidian vault
- frontmatter + backlinks 必填（用于追溯与证据回跳）

## 3. P1：Publish Connector
- TechCard/Playbook/SessionSummary 一键发布
- Notebook 编辑默认不回写（可选：comment 回写）

## 4. Markdown 契约（必填）
frontmatter：
- source: ai-learning-os
- version: v0.3.4
- item_type: tech_card | playbook | practice | session | portfolio
- learn_status, verification, interaction_mode, impl_source
- project_id, session_id, source_item_id
- evidence_links: [Replay deep links]
- tags: []

backlinks：
- Open in Replay（deep link）
- Source Item（deep link）

## 5. 未成年人安全
- 默认不导出/不发布全量对话
- Publish 需教师审批（P1）
