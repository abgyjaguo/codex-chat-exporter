# AI Learning OS（未成年人版 7–18）PRD（PBL / MVP）v0.3.4
日期：2025-12-30

> 关键：未成年人默认以“安全作品集输出”为主，不分享全量对话。

## 1. OpenNotebook 是否必须
不必须。MVP 只需完成：项目学习 → Explain/Test/Evidence → 老师审阅。

## 2. P0：Portfolio 安全导出（新增）
- 包含：Explain + Evidence + Reflection + 作品链接
- 隐藏：raw chat transcripts
- 导出：PDF（可选）+ Markdown（用于 Notebook/存档）

## 3. P1：Publish to Notebook（需教师审批）
- 教师审批后允许发布 Portfolio（仍为安全版）
