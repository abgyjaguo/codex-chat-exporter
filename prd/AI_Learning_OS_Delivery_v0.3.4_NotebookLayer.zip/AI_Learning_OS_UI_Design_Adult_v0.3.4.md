# 成人版 UI 设计（新增 Export/Publish）v0.3.4
日期：2025-12-30

## 新增页面
- Export Center（P0）：`adult_16_export_center.png`
- Publish Modal（P1 占位）：`adult_15_publish_to_notebook_modal.png`

## 交互要点
- P0 仅导出 ZIP（不依赖 Notebook API）
- 每个 md 必带 frontmatter + backlinks（证据可回跳）
