# AI Learning OS（成人学习版）PRD（MVP）v0.3.4
日期：2025-12-30

> 本版本核心：引入 **双层架构（System of Record + Knowledge Surface）**：
> - AI Learning OS 是权威数据源（证据/验证/状态/规则引擎）
> - OpenNotebook/Obsidian 是知识呈现与编辑层（可插拔），采用 **单向发布（One-way publish）** 为主

---

## 0. 一句话定位
成人版：通过“跟 AI 学习”更了解 AI 在做什么、更会使用 AI、更会管理 AI；将会话中的关键技术点做 **可验证（Verified）+可复现（Practice）+可资产化（Tech Card/Playbook）**，并可发布到个人知识库长期沉淀。

## 1. OpenNotebook 是否必须
不必须。MVP 完整闭环不依赖 Notebook：导入 → Inbox → Practice/资产 → 回写证据与状态。

## 2. 用在哪里（最合适）
- **P0：Export Markdown ZIP**（零集成，导入 OpenNotebook/Obsidian）
- **P1：Publish to OpenNotebook**（API 直连，一键发布）
- **P2：知识可视化/图谱**（优先由 Notebook 承担）
- **不建议：P2 之前做双向同步**（一致性/冲突成本巨大）

## 3. 信息架构（新增）
- Projects / Inbox / Replay / Practice / Knowledge / Library
- **Export Center（P0）**
- **Notebook Settings（P1 可隐藏）**

## 4. P0 功能（新增）
### 4.1 Export Center
- 范围：项目/会话/时间窗
- 内容：TechCards/Playbooks/Practices/Sessions
- 导出：ZIP（版本化 export-001…）
- 历史：可下载、可复用配置

### 4.2 Markdown 契约（必填）
- frontmatter：learn_status / verification / interaction_mode / evidence_links / ids
- backlinks：Open in Replay + Source Item

## 5. 成功指标（新增）
- 导出使用率（exports / WAU）
- 资产化率（Verified 的 TechCard/Playbook）
- Practice 转化（To learn → Practiced → Mastered）
